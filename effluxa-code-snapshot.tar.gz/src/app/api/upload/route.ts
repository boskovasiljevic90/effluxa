export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import jwt from "jsonwebtoken";
import OpenAI from "openai";
import * as XLSX from "xlsx";
import { trackEvent } from "@/lib/events";
import { trackError } from "@/lib/errorTracking";
import { getWorkspaceOwner } from "@/lib/workspace";

export const runtime = "nodejs";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY!,
});

function extractJSON(text: string) {
  const cleaned = text
    .replace(/```json/g, "")
    .replace(/```/g, "")
    .trim();

  const match = cleaned.match(/\{[\s\S]*\}/);
  if (!match) return null;

  return match[0]
    .replace(/,\s*}/g, "}")
    .replace(/,\s*]/g, "]");
}

function safeParseAIJson(raw: string) {
  const jsonString = extractJSON(raw);

  if (!jsonString) {
    throw new Error("AI did not return JSON.");
  }

  try {
    return JSON.parse(jsonString);
  } catch {
    throw new Error("AI returned invalid JSON. Please try again.");
  }
}

async function analyzeWithAI(file: File, financialText?: string) {
  const isPdf = file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf");

  const content: any[] = [];

  if (isPdf) {
    const buffer = Buffer.from(await file.arrayBuffer());
    const base64File = `data:application/pdf;base64,${buffer.toString("base64")}`;

    content.push({
      type: "input_file",
      file_data: base64File,
      filename: file.name,
    });
  }

  content.push({
    type: "input_text",
    text: `
You are Effluxa, a senior AI financial leakage auditor for small and mid-sized businesses.

Your job is to analyze uploaded financial documents and identify:
- unnecessary cost leakage
- overspending patterns
- vendor concentration risks
- duplicate or suspicious payments
- cash flow pressure
- operational inefficiencies
- practical savings opportunities

Return ONLY valid JSON.
Do not use markdown.
Do not add comments.
Do not add trailing commas.
If the document does not contain enough information for a field, use an empty array or "Insufficient data".

Return exactly this JSON structure:

{
  "executive_summary": "clear executive summary in 3-5 sentences",
  "leakage_score": 0,
  "risk_level": "Low | Medium | High | Critical",
  "estimated_savings": 0,
  "confidence_level": "Low | Medium | High",
  "key_findings": ["finding 1", "finding 2", "finding 3"],
  "top_vendors": [
    { "vendor": "Vendor name", "amount": 0, "reason": "why this vendor matters" }
  ],
  "high_cost_categories": [
    { "category": "Category name", "amount": 0, "observation": "cost observation" }
  ],
  "anomalies": [
    { "item": "Anomaly", "reason": "why it may require review" }
  ],
  "duplicate_payment_risks": [
    { "item": "Possible duplicate", "reason": "why it may be duplicate" }
  ],
  "cashflow_observations": ["observation 1", "observation 2"],
  "quick_wins": ["quick win 1", "quick win 2", "quick win 3"],
  "recommendations": ["recommendation 1", "recommendation 2", "recommendation 3"],
  "cfo_summary": "short CFO-style conclusion"
}

Rules:
- leakage_score must be 0-100.
- estimated_savings must be numeric EUR estimate.
- Do not invent vendor names if not visible.
- If amounts are unclear, be conservative.
- Focus on practical business action, not generic advice.
- For weak or incomplete documents, explicitly say data is limited.

Financial data:
${financialText ? financialText.slice(0, 30000) : ""}
`
  });

  const response = await openai.responses.create({
    model: "gpt-4.1",
    input: [
      {
        role: "user",
        content,
      },
    ],
  });

  return safeParseAIJson(response.output_text || "");
}

export async function POST(req: NextRequest) {
  try {
    const token = req.cookies.get("token")?.value;

    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as {
      userId: string;
    };

    const user = await prisma.user.findUnique({
      where: {
        id: decoded.userId,
      },
    });

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    const workspace = await getWorkspaceOwner(user);

    if (!workspace.hasBusinessAccess && user.weeklyUploadCount >= 3) {
      return NextResponse.json(
        {
          error: "You have reached your free audit limit. You can still unlock existing reports for €29, or contact support for more access.",
        },
        { status: 403 }
      );
    }

    const formData = await req.formData();
    const file = formData.get("file") as File | null;
    const rawClientId = formData.get("clientId") as string | null;
    const clientId = rawClientId?.trim() || null;

    if (!file) {
      return NextResponse.json({ error: "No file uploaded" }, { status: 400 });
    }

    const client = clientId
      ? await prisma.client.findFirst({
          where: {
            id: clientId,
            ownerId: workspace.owner.id,
          },
        })
      : null;

    if (clientId && !client) {
      return NextResponse.json(
        { error: "Selected client was not found in this workspace." },
        { status: 400 }
      );
    }

    const allowedExtensions = [".pdf", ".csv", ".xlsx", ".xls"];
    const lowerName = file.name.toLowerCase();

    const validFile = allowedExtensions.some((ext) =>
      lowerName.endsWith(ext)
    );

    if (!validFile) {
      return NextResponse.json(
        { error: "Only PDF, CSV, XLSX, and XLS files are supported." },
        { status: 400 }
      );
    }

    const maxSize = 10 * 1024 * 1024;

    if (file.size > maxSize) {
      return NextResponse.json(
        { error: "File too large. Maximum size is 10MB." },
        { status: 400 }
      );
    }

    let financialText = "";

    if (lowerName.endsWith(".csv")) {
      financialText = await file.text();
    }

    if (lowerName.endsWith(".xlsx") || lowerName.endsWith(".xls")) {
      const buffer = Buffer.from(await file.arrayBuffer());

      const workbook = XLSX.read(buffer, {
        type: "buffer",
      });

      financialText = workbook.SheetNames.map((sheetName) => {
        const sheet = workbook.Sheets[sheetName];
        return `Sheet: ${sheetName}\n${XLSX.utils.sheet_to_csv(sheet)}`;
      }).join("\n\n");
    }

    const parsedData = await analyzeWithAI(file, financialText);

    const upload = await prisma.upload.create({
      data: {
        userId: workspace.owner.id,
        fileUrl: file.name,
        parsedData,
        summary: "AI financial leak audit generated",
        clientId: client?.id || null,
      },
    });

    await prisma.user.update({
      where: {
        id: user.id,
      },
      data: {
        weeklyUploadCount: {
          increment: 1,
        },
      },
    });

    await trackEvent({
      type: "upload_created",
      userId: user.id,
      reportId: upload.id,
      metadata: {
        fileName: file.name,
        fileSize: file.size,
        workspaceOwnerId: workspace.owner.id,
        uploadedBy: user.email,
        clientId: client?.id || null,
        clientName: client?.name || null,
      },
    });

    return NextResponse.json({
      success: true,
      upload,
    });
  } catch (error: any) {
    console.error("UPLOAD ERROR:", error);
    await trackError({ type: "upload_error", error });

    return NextResponse.json(
      { error: error.message || "Upload failed" },
      { status: 500 }
    );
  }
}